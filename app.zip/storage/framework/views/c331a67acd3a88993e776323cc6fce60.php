<?php $__env->startSection('title', 'Purchase Index'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3 class="card-title">
                <i class="fas fa-user-graduate"></i> Purchases
            </h3>
            <div class="card-actions">
                <a href="<?php echo e(route('purchase.create')); ?>" class="btn btn-primary d-none d-sm-inline-block">
                    <i class="fas fa-plus"></i> Add Purchase
                </a>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped table-hover datatable display">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Date</th>
                    <th>Reference</th>
                    <th>Supplier</th>
                    <th>Purchase Status</th>
                    <th>Grand Total</th>
                    <th>Paid Amount</th>
                    <th>Due</th>
                    <th>Payment Status</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                            $subTotal = $purchase->purchaseOrders->sum('subTotal');
                            $paidAmount = $purchase->purchasePayments->sum('amount');
                            $dueAmount = $subTotal - $paidAmount;
                            $allPayments = $purchase->purchasePayments;
                    ?>
                    <tr>
                        <td><?php echo e($purchase->purchaseID); ?></td>
                        <td><?php echo e($purchase->date); ?></td>
                        <td><?php echo e($purchase->refID); ?></td>
                        <td><?php echo e($purchase->account->name); ?></td>
                        <td><div class="badge badge-success"><?php echo e($purchase->purchaseStatus->name); ?></div></td>
                        <td><?php echo e($subTotal); ?></td>
                        <td><?php echo e($paidAmount); ?></td>
                        <td><?php echo e($dueAmount); ?></td>
                        <td> <?php if($dueAmount > 0): ?> <div class="badge badge-danger">Due</div> <?php else: ?> <div class="badge badge-success">Paid</div> <?php endif; ?></td>
                        <td>
                            <div class="dropdown">
                                <button class="btn dropdown-toggle form-select" type="button" id="dropdownMenuButton_<?php echo e($purchase->purchaseID); ?>" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Actions
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton_<?php echo e($purchase->purchaseID); ?>">
                                    <a class="dropdown-item" href="<?php echo e(route('purchase.show', $purchase->purchaseID)); ?>">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('purchase.edit', $purchase->purchaseID)); ?>">
                                        <i class="text-yellow fa fa-edit"></i> Edit
                                    </a>

                                    <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#receiveProductModal_<?php echo e($purchase->purchaseID); ?>">
                                        <i class="text-yellow fa fa-plus"></i> Receive Products
                                    </a>

                                    <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#addPaymentModal_<?php echo e($purchase->purchaseID); ?>">
                                        <i class="text-yellow fa fa-plus"></i> Add Payment
                                    </a>

                                    <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#viewPaymentModal_<?php echo e($purchase->purchaseID); ?>">
                                        <i class="text-yellow fa fa-plus"></i> View Payments
                                    </a>

                                    <form action="<?php echo e(route('purchase.destroy', $purchase->purchaseID)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this?');" style="display: inline-block;">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item">
                                            <i class="text-red fa fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <div class="modal fade" id="addPaymentModal_<?php echo e($purchase->purchaseID); ?>" tabindex="-1" aria-labelledby="addPaymentModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg"> <!-- Add "modal-dialog-white" class -->
                            <div class="modal-content" style="background-color: white; color: #000000"> <!-- Add "modal-content-white" class -->
                                <div class="modal-header">
                                    <h5 class="modal-title" id="addPaymentModalLabel" style="color: black; font-weight: bold">Add Payment <?php echo e($purchase->purchaseID); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form class="form-horizontal" action="<?php echo e(route('purchase.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="purchaseID" value="<?php echo e($purchase->purchaseID); ?>">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-6 col-lg-6 mt-1">
                                                <label>Receivable Amount *</label>
                                                <input type="number" name="amount" class="form-control" value="<?php echo e($subTotal); ?>" step="any" disabled>
                                            </div>

                                            <div class="col-sm-12 col-md-6 col-lg-6 mt-1">
                                                <label>Paying Amount *</label>
                                                <input type="number" name="amount" class="form-control" step="any" required>
                                            </div>

                                            <div class="col-sm-12 col-md-6 col-lg-6 mt-2">
                                                <label>Change :</label>
                                                <span>0.00</span>
                                            </div>

                                            <div class="col-sm-12 col-md-6 col-lg-6 mt-1">
                                                <label>Date</label>
                                                <input type="hidden" name="paidBy" value="a">
                                               <input type="date" name="date" id="date" class="form-control">
                                            </div>

                                            <div class="col-12 mt-2">
                                                <label>Account: </label>
                                                <select name="accountID" class="form-select" required>
                                                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($account->accountID); ?>" <?php echo e(old('accountID') == $account->accountID ? 'selected' : ''); ?>><?php echo e($account->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>

                                            <div class="col-12 mt-2">
                                                <label>Payment Note: </label>
                                                <textarea type="text" name="description" rows="5" class="form-control"></textarea>
                                            </div>
                                        </div>

                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <input class="btn btn-primary" type="submit" value="Save">
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal fade" id="viewPaymentModal_<?php echo e($purchase->purchaseID); ?>" tabindex="-1" aria-labelledby="viewPaymentModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content" style="background-color: white; color: #000000">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="viewPaymentModalLabel" style="color: black; font-weight: bold">View Payment <?php echo e($purchase->purchaseID); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body modal-body-scrollable">
                                    <ul class="list-group">
                                        <?php $__currentLoopData = $allPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <strong class="text-primary">Payment Date:</strong>
                                                        <span class="text-secondary"><?php echo e($payment->date); ?></span>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <strong class="text-primary">From Amount:</strong>
                                                        <span class="text-secondary"><?php echo e($payment->amount); ?></span>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <strong class="text-primary">Account:</strong>
                                                        <span class="text-secondary"><?php echo e($payment->account->name); ?></span>
                                                    </div>
                                                    <div class="col-md-12 mt-2">
                                                        <strong class="text-primary">Description:</strong>
                                                        <span class="text-secondary"><?php echo e($payment->description); ?></span>
                                                    </div>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal fade" id="receiveProductModal_<?php echo e($purchase->purchaseID); ?>" tabindex="-1" aria-labelledby="receiveProductModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-xl"> <!-- Add "modal-dialog-white" class -->
                            <div class="modal-content" style="background-color: white; color: #000000"> <!-- Add "modal-content-white" class -->
                                <div class="modal-header">
                                    <h5 class="modal-title" id="receiveProductModalLabel" style="color: black; font-weight: bold">Receive Order Products <?php echo e($purchase->purchaseID); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form class="form-horizontal" action="<?php echo e(route('purchaseReceive.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="purchaseID" value="<?php echo e($purchase->purchaseID); ?>">
                                        <?php
                                            $uniqueProducts = [];
                                            $receivedQuantity = [];
                                            $summedData = [];
                                        ?>
                                        <?php $__currentLoopData = $purchase->purchaseReceive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $productID = $order['productID'];
                                                $orderedQty = $order['orderedQty'] ?? 0;
                                                $receivedQty = $order['receivedQty'] ?? 0;

                                                if (!isset($summedData[$productID])) {
                                                    $summedData[$productID] = [
                                                        'productID' => $productID,
                                                        'orderedQty' => $orderedQty,
                                                        'receivedQty' => $receivedQty
                                                    ];
                                                } else {
                                                    $summedData[$productID]['orderedQty'] += $orderedQty;
                                                    $summedData[$productID]['receivedQty'] += $receivedQty;
                                                }
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php
                                            $allProductsReceived = true;
                                        ?>

                                        <?php $__empty_1 = true; $__currentLoopData = $summedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php
                                                $modifiedOrderedQty = $data['orderedQty'] - $data['receivedQty'];
                                                $productID = $data['productID'];
                                                $productName = \App\Models\Product::where('productID', $productID)->pluck('name');
                                            ?>

                                            <?php if($modifiedOrderedQty != 0): ?>
                                                <?php $allProductsReceived = false; ?>

                                                <div class="form-group row">
                                                    <div class="col-sm-12 col-md-4">
                                                        <label class="control-label">Product Name:</label>
                                                        <span class="form-control-static"><?php echo e($productName[0]); ?></span>
                                                    </div>
                                                    <div class="col-sm-12 col-md-4">
                                                        <label class="control-label">Order Quantity:</label>
                                                        <span class="form-control-static"><?php echo e($modifiedOrderedQty); ?></span>
                                                    </div>
                                                    <div class="col-sm-12 col-md-4">
                                                        <label class="control-label">Receive Quantity:</label>
                                                        <input type="number" name="receiveQty_<?php echo e($data['productID']); ?>" class="form-control receive-quantity" value="<?php echo e($modifiedOrderedQty); ?>">
                                                        <span class="invalid-feedback" style="display: none;">Receive quantity cannot exceed order quantity.</span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <p>No</p>
                                        <?php endif; ?>

                                        <?php if($allProductsReceived): ?>
                                            <div class="text-center mb-3 ">
                                                <span class="fw-bold" style="font-size: 1.2rem;">All Products Received</span>
                                            </div>
                                        <?php endif; ?>





                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <input class="btn btn-primary" type="submit" value="Save">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('more-script'); ?>
    <script>
        $(document).ready(function() {
            $('.receive-quantity').on('input', function() {
                var orderQty = parseInt($(this).parent().prev().find('.form-control-static').text());
                var receiveQty = parseInt($(this).val());

                if (receiveQty > orderQty) {
                    $(this).addClass('is-invalid');
                    $(this).next('.invalid-feedback').show();
                } else {
                    $(this).removeClass('is-invalid');
                    $(this).next('.invalid-feedback').hide();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posLatest\resources\views/purchase/index.blade.php ENDPATH**/ ?>