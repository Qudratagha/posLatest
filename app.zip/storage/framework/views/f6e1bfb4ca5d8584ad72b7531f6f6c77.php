<?php $__env->startSection('title', 'Category Create'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card card-default color-palette-box">
        <div class="card-header">
            <h4 class="card-title fw-semibold">
                <i class="fas fa-users-cog"></i> Add New Category
            </h4>
        </div>
        <div class="card-body">
            <form class="form-horizontal" action="<?php echo e(route('category.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <label for="name" class=" form-label required col-sm-4 col-md-2 col-lg-2  col-form-label">Category Name: </label>
                    <div class="col-sm-4 col-md-4 col-lg-4">
                        <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
                    </div>
                </div>

                <div class="form-group row mt-2">
                    <label for="parentID" class="form-label required col-sm-4 col-md-2 col-lg-2  col-form-label">Parent Category: </label>
                    <div class="col-sm-4 col-md-4 col-lg-4 ">
                        <select name="parentID" class="form-select">
                            <option value="">Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->categoryID); ?>" <?php echo e(old('parentID') == $category->categoryID ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="form-group row mt-2 py-2">
                    <label for="name" class="form-label required col-sm-4 col-md-2 col-lg-2  col-form-label">Active: </label>
                    <div class="col-sm-4 col-md-4 col-lg-4">
                        <label class="form-check form-check-inline">
                            <input type="radio" class="form-check-input" name="isActive" value="0" <?php if(!old('isActive')): ?> checked <?php endif; ?>> <span class="form-check-label">Yes</span>
                        </label>
                        <label class="form-check form-check-inline">
                            <input type="radio" class="form-check-input" name="isActive" value="1" <?php if(old('isActive')): ?> checked <?php endif; ?>> <span class="form-check-label">No</span>
                        </label>
                    </div>
                </div>

                <div class="form-group row mt-1">
                    <label for="tags" class="form-label col-sm-4 col-md-2 col-lg-2 col-form-label">Picture: </label>
                    <div class="col-sm-8 col-md-4 col-lg-4">
                        <input type="file" name="image" class="form-control" required>
                    </div>
                </div>

                <div class="form-group row mt-2">
                    <div class="offset-2">
                        <input class="btn btn-primary" type="submit" value="Save">
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posLatest\resources\views/category/create.blade.php ENDPATH**/ ?>