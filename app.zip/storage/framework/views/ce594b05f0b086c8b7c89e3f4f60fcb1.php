<?php $__env->startSection('title', 'Account Show'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3 class="card-title">
                <i class="fas fa-user-graduate"></i> <?php echo e(ucfirst($account->name)); ?>

            </h3>
            <div class="card-actions">
                <a class="btn btn-primary d-none d-sm-inline-block"  href="<?php echo e(route("account.edit",$account->accountID)); ?>" >
                    <i class="fas fa-edit"></i> Edit Account
                </a>
            </div>
        </div>
        <div class="card-body">
            <dl class="row">
                <div class="col-md-6">
                    <dt class="fs-5">Account Name:</dt>
                    <dd class="fs-5"><?php echo e($account->name); ?></dd>

                    <dt class="fs-5">Account Number:</dt>
                    <dd class="fs-5"><?php echo e($account->accountNumber); ?></dd>

                    <dt class="fs-5">Account Type:</dt>
                    <dd class="fs-5"><?php echo e($account->type); ?></dd>

                    <dt class="fs-5">Account Category:</dt>
                    <dd class="fs-5"><?php echo e($account->category); ?></dd>
                </div>
                <div class="col-md-6">
                    <dt class="fs-5">Phone:</dt>
                    <dd class="fs-5"><?php echo e($account->phone); ?></dd>

                    <dt class="fs-5">Email:</dt>
                    <dd class="fs-5"><?php echo e($account->email); ?></dd>

                    <dt class="fs-5">Description:</dt>
                    <dd class="fs-5"><?php echo e($account->description); ?></dd>

                    <dt class="fs-5">Address:</dt>
                    <dd class="fs-5"><?php echo e($account->address); ?></dd>
                </div>
            </dl>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posLatest\resources\views/account/show.blade.php ENDPATH**/ ?>