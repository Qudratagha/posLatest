<?php $__env->startSection('title', 'Account Show'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3 class="card-title">
                <i class="fas fa-user-graduate"></i>
            </h3>
            <div class="card-actions">
                <a class="btn btn-primary d-none d-sm-inline-block"  href="<?php echo e(route("purchase.edit",$purchase->purchaseID)); ?>" >
                    <i class="fas fa-edit"></i> Edit Purchase
                </a>
            </div>
        </div>
        <div class="card-body">
            <dt>
                <div class="card-body">
                    <dl class="row">
                        <h3 class="text-center">Details</h3>
                        <div class="col-md-12">
                            <h5 class="text-center mb-3 mt-3">Purchase Details</h5>
                            <dl class="row">
                                <div class="col-sm-6">
                                    <dt class="fs-5">Supplier Name:</dt>
                                    <dd class="fs-5"><?php echo e($purchase->account->name); ?></dd>
                                </div>
                                <div class="col-sm-6">
                                    <dt class="fs-5">Purchase Status:</dt>
                                    <dd class="fs-5"><?php echo e($purchase->purchaseStatus->name); ?></dd>
                                </div>
                                <div class="col-sm-6">
                                    <dt class="fs-5">Order Tax:</dt>
                                    <dd class="fs-5"><?php echo e($purchase->orderTax); ?></dd>
                                </div>
                                <div class="col-sm-6">
                                    <dt class="fs-5">Shipping Cost:</dt>
                                    <dd class="fs-5"><?php echo e($purchase->shippingCost); ?></dd>
                                </div>
                                <div class="col-sm-6">
                                    <dt class="fs-5">Description:</dt>
                                    <dd class="fs-5"><?php echo e($purchase->description); ?></dd>
                                </div>
                                <div class="col-sm-6">
                                    <dt class="fs-5">Date:</dt>
                                    <dd class="fs-5"><?php echo e($purchase->date); ?></dd>
                                </div>
                            </dl>
                        </div>

                        <div class="col-md-12">
                            <h5 class="text-center mb-3">Purchase Orders</h5>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead class="thead-dark">
                                    <tr>
                                        <th>Product Name</th>
                                        <th>Warehouse</th>
                                        <th>Code</th>
                                        <th>Quantity</th>
                                        <th>Batch Number</th>
                                        <th>Expiry Date</th>
                                        <th>Net Unit Cost</th>
                                        <th>Discount</th>
                                        <th>Tax</th>
                                        <th>Total</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $purchaseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($order->product->name); ?></td>
                                            <td><?php echo e($order->warehouse->name); ?></td>
                                            <td><?php echo e($order->code); ?></td>
                                            <td><?php echo e($order->quantity); ?></td>
                                            <td><?php echo e($order->batchNumber ?? ''); ?></td>
                                            <td><?php echo e($order->expiryDate ?? ''); ?></td>
                                            <td><?php echo e($order->netUnitCost); ?></td>
                                            <td><?php echo e($order->discount); ?></td>
                                            <td><?php echo e($order->tax); ?></td>
                                            <td><?php echo e($order->subTotal); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                        <div class="col-md-12">
                            <h5 class="text-center mb-3">Purchase Receive</h5>
                            <div class="table-responsive">

                                <table class="table table-bordered">
                                    <thead class="thead-dark">
                                    <tr>
                                        <th>Product Name</th>
                                        <th>Received Quantity</th>
                                        <th>Date</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $purchaseReceives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($receive->product->name); ?></td>
                                            <td><?php echo e($receive->receivedQty); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($receive->date)->format('Y-m-d')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </dl>
                </div>


            </dt>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posLatest\resources\views/purchase/show.blade.php ENDPATH**/ ?>