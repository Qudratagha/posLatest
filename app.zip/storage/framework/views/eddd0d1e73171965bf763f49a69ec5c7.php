<?php $__env->startSection('title', 'Unit Index'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3 class="card-title">
                <i class="fas fa-user-graduate"></i> Units
            </h3>
            <div class="card-actions">
                <a href="<?php echo e(route('unit.create')); ?>" class="btn btn-primary d-none d-sm-inline-block">
                    <i class="fas fa-plus"></i> Add Unit
                </a>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped table-hover datatable display">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Unit Name</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($unit->unitID); ?></td>
                        <td><?php echo e($unit->name); ?></td>

                        <td>
                            <a href="<?php echo e(route('unit.show', $unit->unitID)); ?>">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a class="ps-1 pe-1" href="<?php echo e(route('unit.edit', $unit->unitID)); ?>">
                                <i class="text-yellow fa fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('unit.destroy', $unit->unitID)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this?');" style="display: inline-block;">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <a class="ps-1 pe-1" href="javascript:void(0);" onclick="$(this).closest('form').submit();">
                                    <i class="text-red fa fa-trash"></i>
                                </a>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posLatest\resources\views/unit/index.blade.php ENDPATH**/ ?>