<?php $__env->startSection('title', 'Unit Create'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card card-default color-palette-box">
        <div class="card-header">
            <h4 class="card-title fw-semibold">
                <i class="fas fa-users-cog"></i> Add New Unit
            </h4>
        </div>
        <div class="card-body">
            <form class="form-horizontal" action="<?php echo e(route('unit.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <label for="name" class=" form-label required col-sm-4 col-md-2 col-lg-2  col-form-label">Unit Name: </label>
                    <div class="col-sm-4 col-md-4 col-lg-4">
                        <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required placeholder="Unit Name">
                    </div>
                </div>

                <div class="form-group row mt-2">
                    <label for="code" class=" form-label required col-sm-4 col-md-2 col-lg-2  col-form-label" >Unit Code: </label>
                    <div class="col-sm-4 col-md-4 col-lg-4">
                        <input type="number" name="code" class="form-control" value="<?php echo e(old('code')); ?>" required placeholder="Unit Code">
                    </div>
                </div>

                <div class="form-group row mt-2">
                    <label for="parentID" class="form-label required col-sm-4 col-md-2 col-lg-2  col-form-label">Parent Unit: </label>
                    <div class="col-sm-4 col-md-4 col-lg-4 ">
                        <select name="parentID" class="form-select">
                            <option value="">Select Parent</option>
                            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($unit->unitID); ?>" <?php echo e(old('parentID') == $unit->unitID ? 'selected' : ''); ?>><?php echo e($unit->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="form-group row mt-2 ">
                    <label for="operator" class=" form-label required col-sm-4 col-md-2 col-lg-2  col-form-label">Unit Operator: </label>
                    <div class="col-sm-4 col-md-4 col-lg-4">
                        <input type="text" name="operator" class="form-control" value="<?php echo e(old('operator')); ?>" required placeholder="Unit Operator">
                    </div>
                </div>

                <div class="form-group row mt-2">
                    <label for="value" class=" form-label required col-sm-4 col-md-2 col-lg-2  col-form-label">Unit Value: </label>
                    <div class="col-sm-4 col-md-4 col-lg-4">
                        <input type="number" name="value" class="form-control" value="<?php echo e(old('value')); ?>" required placeholder="Unit Value">
                    </div>
                </div>

                <div class="form-group row mt-2">
                    <div class="offset-2">
                        <input class="btn btn-primary" type="submit" value="Save">
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posLatest\resources\views/unit/create.blade.php ENDPATH**/ ?>