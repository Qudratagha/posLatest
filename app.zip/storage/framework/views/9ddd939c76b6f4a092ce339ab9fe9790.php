<?php $__env->startSection('title', 'Category Create'); ?>
<?php $__env->startSection('content'); ?>
    <div class="middle-content container-xxl p-0">

        <div class="card card-default color-palette-box">
            <div class="card-header">
                <h4 class="card-title fw-semibold">
                    <i class="fas fa-users-cog"></i> Add New Product
                </h4>
                <!-- Add a container with the text-center class -->
                <div class="text-center">
                    <!-- Button 1 -->
                    <button class="btn btn-sm btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#addBrandModal">
                        <span class="fs-6">Add Brand</span>
                    </button>

                    <!-- Button 2 -->
                    <button class="btn btn-sm btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                        <span class="fs-6">Add Category</span>
                    </button>
                </div>
            </div>

            <!-- Brand Modal -->
            <div class="modal fade" id="addBrandModal" tabindex="-1" aria-labelledby="addBrandModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content" style="background-color: white; color: #000000">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addBrandModalLabel">Add Brand</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form class="form-horizontal" action="<?php echo e(route('brand.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="brand" value="brand">
                                <div class="form-group row ">
                                    <label for="name" class="mb-3 form-label required col-form-label col-4">Brand Name: </label>
                                    <div class="mb-3 col-8">
                                        <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
                                    </div>
                                </div>

                                <div class="form-group row ">
                                    <label for="name" class="mb-3 form-label required col-form-label col-4">Active: </label>
                                    <div class="mb-3 col-8">
                                        <label class="form-check form-check-inline">
                                            <input type="radio" class="form-check-input" name="isActive" value="0" <?php if(!old('isActive')): ?> checked <?php endif; ?>> <span class="form-check-label">Yes</span>
                                        </label>
                                        <label class="form-check form-check-inline">
                                            <input type="radio" class="form-check-input" name="isActive" value="1" <?php if(old('isActive')): ?> checked <?php endif; ?>> <span class="form-check-label">No</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save Brand</button>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>


            <!-- Category Modal -->
            <div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content" style="background-color: white; color: #000000">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addCategoryModalLabel">Add Category</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form class="form-horizontal" action="<?php echo e(route('category.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="category" value="category">
                                <div class="form-group row">
                                    <label for="name" class=" form-label required col-form-label col-4">Category Name: </label>
                                    <div class="col-8">
                                        <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
                                    </div>
                                </div>

                                <div class="form-group row mt-2">
                                    <label for="parentID" class="form-label required col-form-label col-4">Parent Category: </label>
                                    <div class="col-8">
                                        <select name="parentID" class="form-select">
                                            <option value="">Select Category</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->categoryID); ?>" <?php echo e(old('parentID') == $category->categoryID ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row mt-2 py-2">
                                    <label for="name" class="form-label required col-form-label col-4">Active: </label>
                                    <div class="col-8">
                                        <label class="form-check form-check-inline">
                                            <input type="radio" class="form-check-input" name="isActive" value="0" <?php if(!old('isActive')): ?> checked <?php endif; ?>> <span class="form-check-label">Yes</span>
                                        </label>
                                        <label class="form-check form-check-inline">
                                            <input type="radio" class="form-check-input" name="isActive" value="1" <?php if(old('isActive')): ?> checked <?php endif; ?>> <span class="form-check-label">No</span>
                                        </label>
                                    </div>
                                </div>

                                <div class="form-group row mt-1 mb-2">
                                    <label for="tags" class="form-label col-form-label col-4">Picture: </label>
                                    <div class="col-8">
                                        <input type="file" name="image" class="form-control" required>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save Category</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


            <div class="card-body">
                <form class="form-horizontal" action="<?php echo e(route('product.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row mb-1">
                        <label for="name" class="form-label required col-sm-4 col-md-6 col-lg-2  col-form-label">Product Name: </label>
                        <div class="col-sm-8 col-md-6 col-lg-4">
                            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required placeholder="Product Name">
                        </div>

                        <label for="code" class="form-label required col-sm-4 col-md-6 col-lg-2 col-form-label">Product Code: </label>
                        <div class="col-sm-8 col-md-6 col-lg-4">
                            <input type="number" name="code" class="form-control" value="<?php echo e(old('code')); ?>" required placeholder="Product Code">
                        </div>
                    </div>

                    <div class="form-group row mb-1">
                        <label for="brandID" class=" form-label required col-sm-6 col-md-6 col-lg-2  col-form-label">Brand : </label>
                        <div class="col-sm-6 col-md-6 col-lg-4">
                            <select name="brandID" class="form-select" required>
                                <option value="">Select Brand</option>
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($brand->brandID); ?>" <?php echo e(old('brandID') == $brand->brandID ? 'selected' : ''); ?>><?php echo e($brand->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <label for="categoryID" class=" form-label required col-sm-6 col-md-6 col-lg-2  col-form-label">Category : </label>
                        <div class="col-sm-6 col-md-6 col-lg-4" >
                            <select name="categoryID" class="form-select" required>
                                <option value="">Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->categoryID); ?>" <?php echo e(old('categoryID') == $category->categoryID ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row mb-1">
                        <label for="productUnit" class=" form-label required col-sm-6 col-md-6 col-lg-2  col-form-label">Product Unit : </label>
                        <div class="col-sm-6 col-md-6 col-lg-4">
                            <select name="productUnit" class="form-select" required>
                                <option value="">Select Unit</option>
                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unit->unitID); ?>" <?php echo e(old('productUnit') == $unit->unitID ? 'selected' : ''); ?>><?php echo e($unit->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <label for="salePrice" class="form-label required col-sm-6 col-md-6 col-lg-2  col-form-label">Sale Price: </label>
                        <div class="col-sm-6 col-md-6 col-lg-4 <?php echo e($errors->has('salePrice') ? 'has-error' : ''); ?>">
                            <input type="number" name="salePrice" class="form-control  <?php if($errors->has('salePrice')): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('salePrice')); ?>" required placeholder="Sale Price">
                        </div>
                    </div>


                    <div class="form-group row mb-1">
                        <label for="purchasePrice" class="form-label required col-sm-6 col-md-6 col-lg-2   col-form-label">Purchase Price: </label>
                        <div class="col-sm-6 col-md-6 col-lg-4">
                            <input type="number" name="purchasePrice" class="form-control" value="<?php echo e(old('purchasePrice')); ?>" required placeholder="Purchase Price">
                        </div>
                        <label for="wholeSalePrice" class="form-label required col-sm-6 col-md-6 col-lg-2   col-form-label">Whole Sale Price: </label>
                        <div class="col-sm-6 col-md-6 col-lg-4">
                            <input type="number" name="wholeSalePrice" class="form-control" value="<?php echo e(old('wholeSalePrice')); ?>" required placeholder="Whole Sale Price">
                        </div>
                    </div>

                    <div class="form-group row mb-1">
                        <label for="alertQuantity" class="form-label required col-sm-6 col-md-6 col-lg-2  col-form-label">Alert Quantity: </label>
                        <div class="col-sm-6 col-md-6 col-lg-4">
                            <input type="number" name="alertQuantity" class="form-control" value="<?php echo e(old('alertQuantity')); ?>" required placeholder="Alert Quantity">
                        </div>
                        <label for="description" class="form-label required col-sm-6 col-md-6 col-lg-2  col-form-label">Description: </label>
                        <div class=" col-sm-6 col-md-6 col-lg-4">
                            <input type="text" name="description" class="form-control" value="<?php echo e(old('description')); ?>" required placeholder="Description">
                        </div>
                    </div>

                    <div class="form-group row mb-1">

                        <label for="image" class=" form-label col-sm-6 col-md-6 col-lg-2 col-form-label">Picture: </label>
                        <div class=" col-sm-6 col-md-6 col-lg-4">
                            <input type="file" name="image" class="form-control">
                        </div>

                        <label for="name" class=" form-label required col-sm-6 col-md-6 col-lg-2  col-form-label">Is-expiry: </label>
                        <div class="col-sm-6 col-md-6 col-lg-4 py-2">
                            <label class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="isExpire" value="0" <?php if(!old('isExpire')): ?> checked <?php endif; ?>> <span class="form-check-label">Yes</span>
                            </label>
                            <label class="form-check form-check-inline">
                                <input type="radio" class="form-check-input" name="isExpire" value="1" <?php if(old('isExpire')): ?> checked <?php endif; ?>> <span class="form-check-label">No</span>
                            </label>
                        </div>
                    </div>

                    <div class="form-group row mt-2">
                        <div class="offset-2">
                            <input class="btn btn-primary" type="submit" value="Save">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posLatest\resources\views/product/create.blade.php ENDPATH**/ ?>