<?php

namespace App\Http\Controllers;

use App\Models\SalePayment;
use Illuminate\Http\Request;

class SalePaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(SalePayment $salePayment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SalePayment $salePayment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, SalePayment $salePayment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SalePayment $salePayment)
    {
        //
    }
}
